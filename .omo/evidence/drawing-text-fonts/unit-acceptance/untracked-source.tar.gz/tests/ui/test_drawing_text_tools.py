# SPDX-FileCopyrightText: 2026 MyCAD contributors
# SPDX-License-Identifier: Apache-2.0
"""Independent drawing text uses document commands and real canvas coordinates."""

from typing import cast
from uuid import uuid4

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from pytestqt.qtbot import QtBot

from mycad.ui.sketch_editor import SketchCanvas


def test_text_placement_cancel_and_one_commit(qtbot: QtBot) -> None:
    from mycad.core.drawing_text import TextStyleTable
    from mycad.ui.drawing_text_tools import DrawingTextTools

    canvas = SketchCanvas(select_committed_entities=True)
    qtbot.addWidget(canvas)
    canvas.resize(600, 400)
    canvas.show()
    tools = DrawingTextTools(canvas)
    tools.sync((), TextStyleTable())
    calls: list[tuple[str, dict[str, object]]] = []
    tools.execute = lambda command, params: calls.append((command, params)) is None
    assert tools.begin("text")
    QTest.mouseClick(canvas, Qt.MouseButton.LeftButton, pos=canvas.local_to_screen((10, 20)))
    tools.editor.setPlainText("中文 ABC")
    QTest.keyClick(tools.editor, Qt.Key.Key_Escape)
    assert not calls
    assert tools.begin("mtext")
    tools.place((10, 20))
    tools.editor.setPlainText("中文 ABC\n第二行")
    QTest.keyClick(tools.editor, Qt.Key.Key_Return, Qt.KeyboardModifier.ControlModifier)
    assert len(calls) == 1
    assert calls[0][0] == "drawing.text.add"
    assert calls[0][1]["text"] == "中文 ABC\n第二行"
    assert calls[0][1]["position_mm"] == [10.0, 20.0]


def test_text_selection_and_transform_use_saved_object(qtbot: QtBot) -> None:
    from mycad.core.drawing_text import DrawingText, TextStyleTable
    from mycad.ui.drawing_text_tools import DrawingTextTools

    canvas = SketchCanvas(select_committed_entities=True)
    qtbot.addWidget(canvas)
    canvas.resize(600, 400)
    canvas.show()
    tools = DrawingTextTools(canvas)
    item = DrawingText(uuid4().hex, "ABC", (0, 0))
    tools.sync((item,), TextStyleTable())
    assert tools.hit((1, 1)) is not None
    tools.selected_ids = {item.text_id}
    calls: list[tuple[str, dict[str, object]]] = []
    tools.execute = lambda command, params: calls.append((command, params)) is None
    assert tools.transform("move", (0, 0), (10, 5))
    updates = calls[0][1]["update"]
    assert isinstance(updates, list)
    assert updates[0]["position_mm"] == [10.0, 5.0]


def test_main_window_text_history_and_cli(qtbot: QtBot) -> None:
    from mycad import app
    from mycad.ui.main_window import MainWindow

    services = app.build_app(discoverers=())
    window = MainWindow(services=services)
    qtbot.addWidget(window)
    window.show()
    window.act_new_drawing.trigger()
    editor = window.active_sketch_dialog()
    loaded = window.loaded_document()
    assert editor is not None and loaded is not None
    tools = editor.canvas.text_tools
    assert tools is not None
    before = loaded.document.command_count
    editor.drawing_command_bar.input.setText('TEXT 10,20 3.5 0 "中文 ABC"')
    editor.drawing_command_bar.submit()
    assert tools.texts, f"{tools.warning.text()} | {editor.canvas.message}"
    assert loaded.document.command_count == before + 1
    assert tools.texts[0].text == "中文 ABC"
    loaded.bus.undo_operation()
    tools.sync(services.kernel.drawing_texts, services.kernel.drawing_text_styles)
    assert not tools.texts
    loaded.bus.redo_operation()
    tools.sync(services.kernel.drawing_texts, services.kernel.drawing_text_styles)
    assert tools.texts[0].text == "中文 ABC"


def test_mixed_saved_text_and_geometry_move_undo(qtbot: QtBot) -> None:
    from mycad import app
    from mycad.core.drawing_text import DrawingText
    from mycad.core.sketch import LineEntity, Sketch, WorkPlaneFrame
    from mycad.ui.main_window import MainWindow

    services = app.build_app(discoverers=())
    window = MainWindow(services=services)
    qtbot.addWidget(window)
    window.show()
    window.act_new_drawing.trigger()
    editor, loaded = window.active_sketch_dialog(), window.loaded_document()
    assert editor is not None and loaded is not None
    line = LineEntity(uuid4().hex, (0, 0), (20, 0))
    sketch = Sketch(uuid4().hex, WorkPlaneFrame.xy(), (line,))
    app.commit_new_sketch(services, loaded, sketch, session_identity=1)
    text = DrawingText(uuid4().hex, "ABC", (0, 10))
    loaded.bus.execute("drawing.text.add", text.to_mapping(), "local")
    editor.set_context_sketches(services.kernel.sketches)
    tools = editor.canvas.text_tools
    assert tools is not None
    tools.sync(services.kernel.drawing_texts, services.kernel.drawing_text_styles)
    editor.canvas.selected_entity_ids = {line.entity_id}
    tools.selected_ids = {text.text_id}
    editor.canvas.begin_transform("move")
    QTest.mouseClick(
        editor.canvas, Qt.MouseButton.LeftButton, pos=editor.canvas.local_to_screen((0, 0))
    )
    QTest.mouseClick(
        editor.canvas, Qt.MouseButton.LeftButton, pos=editor.canvas.local_to_screen((5, 5))
    )
    qtbot.waitUntil(lambda: not window.execution_unit or not window.execution_unit.is_busy)
    assert services.kernel.drawing_texts[0].position_mm == (5, 15)
    loaded.bus.undo_operation()
    assert services.kernel.sketches[0].entities[0] == line
    assert services.kernel.drawing_texts == (text,)


def test_pending_inline_text_blocks_save_and_keeps_edit(qtbot: QtBot) -> None:
    from mycad import app
    from mycad.ui.main_window import MainWindow

    window = MainWindow(services=app.build_app(discoverers=()))
    qtbot.addWidget(window)
    window.show()
    window.act_new_drawing.trigger()
    editor = window.active_sketch_dialog()
    assert editor is not None and editor.canvas.text_tools is not None
    tools = editor.canvas.text_tools
    tools.begin("text")
    tools.place((0, 0))
    tools.editor.setPlainText("尚未提交")
    window.act_save.trigger()
    assert tools.editor.toPlainText() == "尚未提交"
    assert tools.pending
    assert "文字尚未提交" in window.status_command.text()
    from mycad.core.sketch import LineEntity

    editor.canvas.entities = [LineEntity(uuid4().hex, (0, 0), (10, 0))]
    editor.finish_sketch()
    assert editor.result_sketch is None
    assert tools.pending
    window.request_undo()
    assert tools.pending


def test_text_preview_and_degenerate_transform_remain_editable(qtbot: QtBot) -> None:
    from mycad.core.drawing_text import DrawingText, TextStyleTable
    from mycad.ui.drawing_text_tools import DrawingTextTools

    canvas = SketchCanvas(select_committed_entities=True)
    qtbot.addWidget(canvas)
    canvas.resize(600, 400)
    canvas.show()
    tools = DrawingTextTools(canvas)
    text = DrawingText(uuid4().hex, "ABC", (0, 0))
    tools.sync((text,), TextStyleTable())
    tools.selected_ids = {text.text_id}
    tools.edit_selected()
    assert tools.editor.toPlainText() == "ABC"
    canvas.grab()  # Includes an unchanged text preview before any keystroke.
    tools.cancel()
    assert not tools.transform("scale", (0, 0), (0, 0))
    assert "positive" in canvas.message
    assert not tools.transform("mirror", (0, 0), (0, 0))
    assert "distinct" in canvas.message


def test_mixed_text_and_draft_undo_routes_one_document_operation(qtbot: QtBot) -> None:
    from mycad import app
    from mycad.core.drawing_text import DrawingText
    from mycad.core.sketch import LineEntity
    from mycad.ui.main_window import MainWindow

    services = app.build_app(discoverers=())
    window = MainWindow(services=services)
    qtbot.addWidget(window)
    window.show()
    window.act_new_drawing.trigger()
    editor, loaded = window.active_sketch_dialog(), window.loaded_document()
    assert editor is not None and loaded is not None
    tools = editor.canvas.text_tools
    assert tools is not None
    text = DrawingText(uuid4().hex, "ABC", (0, 10))
    assert tools.execute is not None
    tools.execute("drawing.text.add", text.to_mapping())
    line = LineEntity(uuid4().hex, (0, 0), (20, 0))
    editor.canvas.entities = [line]
    editor.canvas.selected_entity_ids = {line.entity_id}
    tools.selected_ids = {text.text_id}
    editor.canvas.begin_transform("move")
    QTest.mouseClick(
        editor.canvas, Qt.MouseButton.LeftButton, pos=editor.canvas.local_to_screen((0, 0))
    )
    QTest.mouseClick(
        editor.canvas, Qt.MouseButton.LeftButton, pos=editor.canvas.local_to_screen((5, 5))
    )
    qtbot.waitUntil(lambda: not window.execution_unit or not window.execution_unit.is_busy)
    assert services.kernel.drawing_texts[0].position_mm == (5, 15)
    assert editor.canvas.entities[0] != line
    window.request_undo()
    qtbot.waitUntil(lambda: not window.execution_unit or not window.execution_unit.is_busy)
    assert services.kernel.drawing_texts == (text,)
    assert editor.canvas.entities == [line]


def test_multiselect_properties_change_only_edited_fields(qtbot: QtBot) -> None:
    from mycad.core.drawing_text import DrawingText, TextStyle, TextStyleTable
    from mycad.ui.drawing_text_tools import DrawingTextTools

    canvas = SketchCanvas(select_committed_entities=True)
    qtbot.addWidget(canvas)
    tools = DrawingTextTools(canvas)
    texts = (
        DrawingText(uuid4().hex, "A", (0, 10), rotation_deg=30),
        DrawingText(uuid4().hex, "B", (20, 30), style_id="other", rotation_deg=60),
    )
    tools.sync(texts, TextStyleTable((TextStyle(), TextStyle("other", "其他"))))
    tools.selected_ids = {item.text_id for item in texts}
    tools.refresh_selection()
    calls: list[dict[str, object]] = []
    tools.execute = lambda command, params: calls.append(params) is None
    tools.height.setValue(5)
    tools.apply_properties()
    raw = calls[0]["update"]
    assert isinstance(raw, list)
    changed = tuple(DrawingText.from_mapping(value) for value in cast("list[object]", raw))
    assert tuple(item.position_mm for item in changed) == ((0, 10), (20, 30))
    assert tuple(item.style_id for item in changed) == ("standard", "other")
    assert tuple(item.rotation_deg for item in changed) == (30, 60)
    assert all(item.height_mm == 5 for item in changed)
